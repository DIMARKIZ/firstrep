<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductTagTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_tag',function (Blueprint $table){
			$table->integer('product_id')
			      ->usigned()
				  ->foreign()
				  ->references('id')
				  ->on('products')
				  ->onDelete('CASCADE')
				  ->onUpdate('RESTRICT')
				  ;
		     $table->integer('tag_id')
			      ->usigned()
				  ->foreign()
				  ->references('id')
				  ->on('tags')
				  ->onDelete('CASCADE')
				  ->onUpdate('RESTRICT')
				  ;
			 $table->primary(['product_id', 'tag_id']);
			 $table->timestamps();
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('product_tag');
    }
}
