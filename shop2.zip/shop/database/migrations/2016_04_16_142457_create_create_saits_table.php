<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCreateSaitsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('create_saits', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title',100);
			$table->text('body');
			$table->string('slug',200);
			$table->boolean('enabled');
			$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('create_saits');
    }
}
