<?php $__env->startSection('content'); ?>

<?php if($posts->count()): ?>
	<?php foreach($posts as $post): ?>
<article>
		<h2><?php echo e($post->title); ?></h2>
		<p><?php echo e(Str_limit($post->body, 50)); ?></p>
		<a href='#'>Читать далее...</a>
</article>
    <?php endforeach; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>