<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post2 extends Model
{
    //
}
