<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class TagController extends Controller
{
    public function index()
	{
		return 'Здесь будет список тегов';
		
	}
	public function create()
	{
		return "Здесь будет формуляр для создания тегов";
	}
	public function edit($id)
	{
		return "Здесь будет формуляр для редактирования тега с идентификатором $id";
	}
	public function delete($id)
	{
		return "Здесь будет формуляр для удаления тега с идентификатором $id";
	}
}
