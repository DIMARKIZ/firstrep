<?php

namespace App\Models;

class Post extends Eloquent {
	
	
}
