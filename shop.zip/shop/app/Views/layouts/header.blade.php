<<!DOCTYPE html>
<html>
<form action="index.html" method="post">
  <p>Имя</p>
  <label>
    <input name="name" type="text">
  </label>
  <p>Фамилия</p>
  <label>
    <input name="familia" type="text">
  </label>
  <p>Логин</p>
  <label>
    <input name="nikname" type="text">
  </label>
  <p>Пароль</p>
  <label>
    <input name="password" type="password">
  </label>
  <p></p>
  	<input type="submit">
	<Body>
       telo
    