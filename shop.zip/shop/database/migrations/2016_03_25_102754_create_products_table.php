<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->increments('id');
			$table->string('title',191)->unique();
			$table->decimal('price',65,2);
			$table->integer('manufacturer_id')
			->unsigned()
			->foreign()
			->references('id')
			->on('manufacturers')
			->onDeleted('RESTRICT')
			->onUpdate('RESTRICT');
			$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('products');
    }
}
