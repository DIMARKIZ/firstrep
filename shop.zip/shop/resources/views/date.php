<html>

<head>

<meta charset='utf-8'/>

<title>Мой сайт</title>

</head>

<body>

     <h1>Сегодня <?php echo $date;?></h1>

</body>